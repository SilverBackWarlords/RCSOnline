export const chainIds = {
  56: "bnb",
  73: "fncy",
  97: "bnb",
  117: "bas-ars",
  230: "bas-gal",
  923018: "fncy",
  14000: "bas-ankr",
  91715: "combo",
  9980: "combo",
  5600: "bnb",
  5601: "bnb",
  5611: "bnb",
  204: "bnb",
  1017: "bnb"
};
